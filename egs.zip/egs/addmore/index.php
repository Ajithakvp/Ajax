<?php
$listOptions = '';
$userType = array(
    "Visiter",
    "Member",
    "Admin"
);
foreach ($userType as $k) {
    $listOptions .= "<option value='" . $k . "'>" . $k . "</option>";
}
?>
<html>
<head>
<title>Load Dynamic Data using jQuery</title>
<link rel="stylesheet" type="text/css" href="css/style.css" />
<link rel="stylesheet" type="text/css" href="css/form.css" />
<script src="https://code.jquery.com/jquery-3.6.1.min.js"
    integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ="
    crossorigin="anonymous"></script>
<link rel="stylesheet"
    href="https://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" />
<script src="https://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
<script>
function setDynamicUI(view) {
    $("#loader").show();
    $("#circle-img").hide();
 	$("<div>").load(view, function() {
    $("#target").append($(this).html());
	$(".userType").html(<?php echo json_encode($listOptions); ?>);
	$('.userDOB').datepicker({
	  changeMonth: true,
	  changeYear: true
	});
     $("#loader").hide();
     $("#circle-img").show();
});
}
$( document ).ready(setDynamicUI("form.php"));
</script>
<style>
#loader {
    display: none;
}

#button-position {
    cursor: pointer;
    display: flex;
    justify-content: center;
}
</style>
</head>
<body>
    <div id="target"></div>
    <div id="button-position">
        <div onClick="setDynamicUI('form.php');" id="circle-img">
            <img src="plus-circle.svg" title="Add" alt="More User" />
            Add More
        </div>
        <img src="spinner.svg" id="loader" alt="missing">
    </div>
</body>
</html>