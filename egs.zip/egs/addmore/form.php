<div class="phppot-container tile-container">
    <div class="row">
        <label>User Type:</label> <select name="userType[]"
            class="userType">
        </select>
    </div>
    <div class="row">
        <label>Date of Birth:</label> <input type="text"
            name="dateAry[]" class="userDOB" />
    </div>
</div>
