
<?php
$connection = mysqli_connect("localhost", "root", ""); // Establishing Connection with Server..
$db = mysqli_select_db($connection,"mydba"); // Selecting Database
//Fetching Values from URL
$name2=$_GET['name1'];
$email2=$_GET['email1'];
$password2=$_GET['password1'];
$contact2=$_GET['contact1'];
//Insert query
$query = mysqli_query($connection,"insert into form_element(name, email, password, contact) values ('$name2', '$email2', '$password2','$contact2')");
echo "Form Submitted Succesfully";
mysqli_close($connection); // Connection Closed
?>
