
$(document).ready(function(){
$("#submitget").click(function(){
var name = $("#name").val();
var email = $("#email").val();
var password = $("#password").val();
var contact = $("#contact").val();
// Returns successful data submission message when the entered information is stored in database.
var dataString = 'name1='+ name + '&email1='+ email + '&password1='+ password + '&contact1='+ contact;
if(name==''||email==''||password==''||contact=='')
{
alert("Please Fill All Fields");
}
else
{
// AJAX Code To Submit Form.
$.ajax({
type: "GET",
url: "ajaxsubmit.php",
data: dataString,
success: function(result){
alert(result);
}
});
}
//return false;
});

$("#submit").click(function(){
	
	var dataString = $( "#frm" ).serialize();
	console.log($("#frm").serializeArray());
	console.log($("#frm").serialize());
// Returns successful data submission message when the entered information is stored in database.

if(($("#name").val()=='')||($("#email").val()=='')||($("#password").val()=='')||($("#contact").val()==''))
{
alert("Please Fill All Fields");
}
else
{
// AJAX Code To Submit Form.

$.ajax({
type: "POST",
url: "ajaxsubmitpost.php",
data: dataString,
success: function(result){
alert(result);
}
});
}

});





});
