
<?php
$connection = mysqli_connect("localhost", "root", ""); // Establishing Connection with Server..
$db = mysqli_select_db($connection,"mydba"); // Selecting Database
//Fetching Values from URL
//print_r($_POST);
$name2=$_POST['name'];
$email2=$_POST['email'];
$password2=$_POST['password'];
$contact2=$_POST['contact'];
//Insert query
$query = mysqli_query($connection,"insert into form_element(name, email, password, contact) values ('$name2', '$email2', '$password2','$contact2')");
echo "Form Submitted Succesfully using POST method";
mysqli_close($connection); // Connection Closed
?>
